package com.PFE.GStagiaire.Controller;

import java.util.Random;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.PFE.GStagiaire.Entity.User;
import com.PFE.GStagiaire.Repository.UserRepository;
import com.PFE.GStagiaire.Service.AuthService;
import com.PFE.GStagiaire.Service.LoginRequest;

@RestController
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/api/login")
    public String login(@RequestBody LoginRequest loginRequest) {
        String login = loginRequest.getlogin();
        String password = loginRequest.getPassword();
        if (authService.authenticate(login, password)) {
            return "Login successful"; // Connexion réussie
        } else {
            return "Invalid login or password"; // Identifiants invalides
        }
        
    }

    @Autowired
    private UserRepository userRepository;

    @PutMapping("/api/forgotPassword")
    public ResponseEntity<String> forgotPassword(@RequestParam String login) {
        User user = userRepository.findByLogin(login);
        if (user != null) {
            // Générer un nouveau mot de passe aléatoire
            String newPassword = generateRandomPassword();

            // Enregistrer le nouveau mot de passe dans la base de données
            user.setPassword(newPassword); // Assurez-vous que votre entité User a une propriété password et une méthode setPassword
            userRepository.save(user);

            // Retourner le nouveau mot de passe dans la réponse de l'API
            return new ResponseEntity<>("Mot de passe réinitialisé pour " + login + ". Le nouveau mot de passe est : " + newPassword, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Utilisateur non trouvé pour le login " + login, HttpStatus.NOT_FOUND);
        }
    }
    
    private String generateRandomPassword() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder newPassword = new StringBuilder();
        Random rnd = new Random();
        while (newPassword.length() < 8) { // Longueur minimale du mot de passe
            int index = (int) (rnd.nextFloat() * characters.length());
            newPassword.append(characters.charAt(index));
        }
        return newPassword.toString();
    } 
    
}
