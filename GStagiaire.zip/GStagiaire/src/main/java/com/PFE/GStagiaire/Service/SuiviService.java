package com.PFE.GStagiaire.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PFE.GStagiaire.Entity.Suivi;
import com.PFE.GStagiaire.Repository.SuiviRepository;


@Service
public class SuiviService {

    @Autowired
    private SuiviRepository suiviRepository;

    public List<Suivi> getAllSuivi() {
        return suiviRepository.findAll();
    }

    public Suivi saveOrUpdateSuivi(Suivi suivi) {
        return suiviRepository.save(suivi);
    }
}
