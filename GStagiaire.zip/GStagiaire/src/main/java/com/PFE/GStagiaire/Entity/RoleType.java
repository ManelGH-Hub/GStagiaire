package com.PFE.GStagiaire.Entity;

public enum RoleType {
	ADMIN,
    ENCADRANT,
    STAGIAIRE
}
