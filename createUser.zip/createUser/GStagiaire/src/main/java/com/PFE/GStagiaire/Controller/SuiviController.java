package com.PFE.GStagiaire.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PFE.GStagiaire.Entity.Suivi;
import com.PFE.GStagiaire.Service.SuiviService;

import java.util.List;

@RestController
@RequestMapping("/api/suivi")
public class SuiviController {

    @Autowired
    private SuiviService suiviService;

    @GetMapping
    public List<Suivi> getSuiviData() {
        return suiviService.getAllSuivi(); // Supposons que vous avez une méthode dans SuiviService pour récupérer toutes les données de suivi
    }
    
    @PostMapping
    public ResponseEntity<?> createSuivi(@RequestBody Suivi suivi) {
        try {
            Suivi savedSuivi = suiviService.saveOrUpdateSuivi(suivi);
            return new ResponseEntity<>(savedSuivi, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>("Failed to create Suivi entry: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        
    }
    
}
