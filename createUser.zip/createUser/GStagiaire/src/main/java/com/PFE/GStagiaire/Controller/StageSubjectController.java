package com.PFE.GStagiaire.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.PFE.GStagiaire.Entity.StageSubject;
import com.PFE.GStagiaire.Repository.StageSubjectRepository;

import java.util.List;
;
@RestController
@RequestMapping("/api/subjects")
public class StageSubjectController {

    @Autowired
    private StageSubjectRepository subjectRepository;

    @GetMapping
    public List<StageSubject> getAllSubjects() {
        return subjectRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<StageSubject> getSubjectById(@PathVariable Long id) {
        StageSubject subject = subjectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found with id: " + id));
        return ResponseEntity.ok(subject);
    }

    @PostMapping
    public ResponseEntity<StageSubject> createSubject(@RequestBody StageSubject subject) {
        StageSubject createdSubject = subjectRepository.save(subject);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdSubject);
    }

    @PutMapping("/{id}")
    public ResponseEntity<StageSubject> updateSubject(@PathVariable Long id, @RequestBody StageSubject subjectDetails) {
        StageSubject subject = subjectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found with id: " + id));

        subject.setTitle(subjectDetails.getTitle());
        subject.setDescription(subjectDetails.getDescription());
        subject.setInternName(subjectDetails.getInternName());
        // Mettez à jour d'autres champs selon les besoins

        StageSubject updatedSubject = subjectRepository.save(subject);
        return ResponseEntity.ok(updatedSubject);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteSubject(@PathVariable Long id) {
        StageSubject subject = subjectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found with id: " + id));

        subjectRepository.delete(subject);
        return ResponseEntity.ok().build();
    }
}

